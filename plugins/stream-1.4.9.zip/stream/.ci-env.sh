export PHPCS_GITHUB_SRC=x-team/PHP_CodeSniffer
export PHPCS_GIT_TREE=subset-selection
export WPCS_GIT_TREE=rule-subset-with-phpcs-pr
export WPCS_STANDARD=WordPress:core-extra
export PHPCS_IGNORE='tests/*,includes/vendor/*,bin/*'
