<div class="wrap">

    <h2>Activate Video User Manuals </h2>

    <p> <strong>Please enter your serial number:</strong> </p>
    
    <form method="post" action="">
        <input type="input" name="serial" style="width:275px" autofocus="autofocus" />
        <br /><br />
        <input type="checkbox" name="applyProfile" value="1" checked="checked" /> Apply my master profile (<a href="http://www.videousermanuals.com/masterprofile/" target="_blank">what's this?</a>)
        <br /><br />
        <input type="submit" value="Activate" class="button-primary" />
    </form>

</div>